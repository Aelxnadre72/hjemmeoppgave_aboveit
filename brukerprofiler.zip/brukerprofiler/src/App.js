import React from 'react';
import './App.css';
import UserProfiles from './pages/UserProfiles';

function App() {
  return (
    <>
      <UserProfiles/>
    </>
  );
}

export default App;
