const fetchAllUsers = async () => {
  try {
    const response = await fetch(
      "https://randomuser.me/api/?results=30&seed=aboveit&exc=login"
    );
    const users = await response.json();
    return users;
  } catch (error) {
    console.log("Error while fetching from api: ", error.message);
  }
};
export default fetchAllUsers;
