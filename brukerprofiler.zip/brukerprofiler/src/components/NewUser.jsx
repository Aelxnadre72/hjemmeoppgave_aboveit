import React, { useState } from "react";
import "../styles/NewUser.css";

const NewUser = () => {
  const [showModal, setShowModal] = useState(false);
  const [user, setUser] = useState({
    gender: "",
    name: { title: "", first: "", last: "" },
  });

  const handleChange = (keys, value) => {
    let newState = { ...user };
    //oppdatere newState med de nye verdiene ved å bruke nøklene for å navigere seg dit.
    setUser(newState);
  };

  const handleSubmit = () => {
    console.log(user);
    setShowModal(false);
  };

  return (
    <>
      <button className="createUserButton" onClick={() => setShowModal(true)}>
        Create new user
      </button>
      {showModal && (
        <div className="modal">
          <button
            className="createUserButton"
            onClick={() => setShowModal(false)}
          >
            Exit
          </button>
          <div>
            <label>
              Gender:
              <input
                type="text"
                value={user.gender}
                onChange={(e) => handleChange(["gender"], e.target.value)}
              />
            </label>

            <label>
              Title:
              <input
                type="text"
                value={user.name.title}
                onChange={(e) =>
                  handleChange(["name", "title"], e.target.value)
                }
              />
            </label>
            <label>
              First Name:
              <input
                type="text"
                value={user.name.first}
                onChange={(e) =>
                  handleChange(["name", "first"], e.target.value)
                }
              />
            </label>
            <label>
              Last Name:
              <input
                type="text"
                value={user.name.last}
                onChange={(e) => handleChange(["name", "last"], e.target.value)}
              />
            </label>
            <button onClick={handleSubmit}>Submit</button>
          </div>
        </div>
      )}
    </>
  );
};

export default NewUser;
