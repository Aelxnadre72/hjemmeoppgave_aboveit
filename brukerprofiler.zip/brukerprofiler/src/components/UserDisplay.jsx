import React from "react";
import "../styles/UserDisplay.css";

const UserDisplay = ({ user }) => {
  return (
    <div className="display">
      <img
        src={user.picture.large}
        alt={`${user.name.first} ${user.name.last}`}
        className="displayImage"
      />
      <div className="displayDetails">
        <div className="column">
          <p>
            <strong>Name:</strong> {user.name.title} {user.name.first}{" "}
            {user.name.last}
          </p>
          <p>
            <strong>Street:</strong> {user.location.street.number}{" "}
            {user.location.street.name}
          </p>
          <p>
            <strong>City:</strong> {user.location.city}
          </p>{" "}
          <p>
            <strong>State:</strong> {user.location.state}
          </p>
          <p>
            <strong>Country:</strong> {user.location.country}
          </p>
          <p>
            <strong>Postcode:</strong> {user.location.postcode}
          </p>
        </div>
        <div className="column">
          <p>
            <strong>Gender:</strong> {user.gender}
          </p>

          <p>
            <strong>Email:</strong> {user.email}
          </p>
          <p>
            <strong>DOB:</strong> {new Date(user.dob.date).toLocaleDateString()}{" "}
            (Age: {user.dob.age})
          </p>
          <p>
            <strong>Phone:</strong> {user.phone}
          </p>
          <p>
            <strong>ID:</strong> {user.id.name} - {user.id.value}
          </p>
        </div>
      </div>
    </div>
  );
};

export default UserDisplay;
