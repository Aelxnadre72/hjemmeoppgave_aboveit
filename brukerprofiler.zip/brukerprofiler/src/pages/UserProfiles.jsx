import React, { useEffect, useState } from "react";
import fetchAllUsers from "../api/UserAPI";
import "../styles/UserProfiles.css";
import UserDisplay from "../components/UserDisplay";
import NewUser from "../components/NewUser";

const UserProfiles = () => {
  const [users, setUsers] = useState([]);
  const [isMoved, setIsMoved] = useState(false);
  const [user, setUser] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      const data = await fetchAllUsers();
      setUsers(data.results);
    };

    fetchUsers();
  }, []);

  const showUserDisplay = (index) => {
    setIsMoved(true);
    setUser(users[index]);
  };

  return (
    <>
      <div>
        <NewUser />
      </div>

      <div>{isMoved ? <UserDisplay user={user} /> : <></>}</div>

      <div className={`userList ${isMoved ? "moved" : ""}`}>
        {users.map((user, index) => (
          <div
            className="userCard"
            key={index}
            onClick={() => showUserDisplay(index)}
          >
            <img
              src={user.picture.large}
              alt={`${user.name.first} ${user.name.last}`}
              className="userImage"
            />
            <div className="userName">
              {user.name.title}. {user.name.first} {user.name.last} <br></br>{" "}
              Age: {user.dob.age}
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default UserProfiles;
